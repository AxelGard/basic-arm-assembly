#include <stdint.h>
#include "util.h"

int main(void)
{
  
  small_printf("\nHello world\n");
  return 0;
}
