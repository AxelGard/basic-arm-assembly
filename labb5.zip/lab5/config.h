/* The size of the map located at MAP_BASE */
#define MAP_XSIZE 2048
#define MAP_YSIZE 2048
#define MAP_XSIZE_LOG2 11

/* The size of the framebuffer (located at FB_FRAME0 or FB_FRAME1) */
#define FB_XSIZE 640
#define FB_YSIZE 480

